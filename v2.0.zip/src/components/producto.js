import React from 'react';

const Producto = ({ producto }) => {

    const {condition, title, price, currency_id, thumbnail} = producto;
    return ( 
        <div className ="col s12 m6 l4">
            <div className="card">
                <div className="card-image">
                    <img src={ thumbnail } alt="Imagen No Disponible"></img>
                </div>
            </div>
            <div className="card-content grey lighten-4">
                <h4>{ title }</h4>
                <p>{price} en {currency_id}</p>
                <p>{condition}</p>
            </div>
        </div>
     );
};
 
export default Producto;
